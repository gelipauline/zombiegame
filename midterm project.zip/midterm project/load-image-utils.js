
const loadbrainImages = (brainImg) => {
    const brainImages = Array.from({length:1}, (el, i) => {
    return brainImg.get(i*240, 240, 240, 240)
    })
}

const loadzombieImages = (zombieImg) => {
    const zombieImages = Array.from({length:3}, (el, i) => {
        return zombieImg.get(i*240 , 240, 240, 240)
    })
}

const loadplantImages = (plantImg) => {
    const plantImages = Array.from({length:1}, (el, i) => { 
    return plantImg.get(i*240,240,240,240)
    })
}


