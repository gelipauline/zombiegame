## a simple mario game written in p5.js

branches:
main is same as 01-starter, project scaffold
-- assets + libraries
-- a few utilities for loading image chunks from spritesheets
-- a background and some ground

02 - Coins
-- a Coin class to display some coins

03 - Mario class
-- moving, jumping

04 - Game
-- refactor to have a Game class
-- start screen, game over screen, scoreboard, sounds

05 - enemies
-- collisions
-- collect coins
-- enemies
-- timer/countdown

-- things you can do --
turn it into a scrolling landscape! in other words, make it longer the current window, and have the landscape move while mario stays in place!
add levels
more enemies or rewards
more landscape features

videos to do:

DAY 11

1. write Game class and move stuff over from sketch
   GameSettings
2. the various screens
   Scoreboard
   Background
   Overlay
3. add sounds

DAY 12

1. bounding box
2. goomba
3. coin collisions
4. goomba collisions
5. game over
