class Background{
    
    render(){
        background(gameSettings.skyColor)
        fill(gameSettings.groundColor)
        rect(0, gamesettings.groundLevel, gamesettings.canvasWidth, gameSettings.canvasHeight - gameSettings.groundLevel)
    }
}